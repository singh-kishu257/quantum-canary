# Quantum Canary

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)

**Real-time noise drift detection for NISQ-era quantum processors.**

Quantum Canary is a physics-informed neural network that detects qubit hardware degradation between IBM Quantum's calibration snapshots, providing researchers with an early-warning signal hours before published calibration data updates.

---

## Why this exists

IBM Quantum refreshes published qubit health data on a daily cycle. Between those snapshots, environmental noise (thermal fluctuations, electromagnetic interference, TLS defects) silently degrades qubit fidelity. Computations run during this unmonitored window may return corrupted results without any indication. Quantum Canary closes this gap.

## Headline results

On a 24-hour live deployment on `ibm_kingston`:

| Method | Test AUC | Notes |
|---|---|---|
| Standard threshold (per-feature majority vote) | 0.7586 | Naive baseline |
| Hotelling's T² (multivariate SPC, 1947) | 0.7674 | Rigorous statistical baseline |
| **Quantum Canary MLP ensemble** | **0.9239** | **+20.4% over Hotelling T²** |

The MLP successfully predicted **3 of 3 IBM recalibration events** with an average lead time of **3.34 hours**.

---

## Quickstart

### Install

```bash
pip install quantum-canary
```

### One-shot drift check

```python
from quantum_canary import Canary

canary = Canary(
    token="YOUR_IBM_QUANTUM_TOKEN",
    instance="YOUR_CRN",
    backend="ibm_kingston",
)

result = canary.check()
print(result)
# {'drift_probability': 0.034, 'verdict': 'STABLE',
#  'uncertainty': 0.001, 'F_bell': 0.987, ...}
```

### Continuous monitoring

```python
canary.monitor(interval_minutes=15, hours=24)
# Logs to logs/realtime_log.csv
# Generates live figure at figures/fig_realtime_canary.png
```

### Command line

```bash
# Single check
quantum-canary check --backend ibm_kingston

# Live deployment
quantum-canary monitor --backend ibm_kingston --hours 24
```

---

## How it works

Three lightweight quantum circuits ("canary circuits") are run on the target backend at regular intervals:

1. **Bell state circuit** — measures 2-qubit entanglement fidelity (F_bell)
2. **Coherence circuit** (20× H identity) — measures T2 dephasing (F_coherence)
3. **Gate error circuit** (20× X identity) — measures single-qubit gate accumulation (F_gate)

The three measured fidelities feed into a 10-seed MLP ensemble trained on a 21,000-sample physics-grounded hybrid dataset (15,000 Qiskit Aer simulations + 6,000 real IBM calibration anchors). The ensemble outputs a drift probability in [0, 1] along with an uncertainty estimate from inter-seed disagreement.

For full details see [`docs/methodology.md`](docs/methodology.md) and [`docs/physics.md`](docs/physics.md).

---

## Repository structure

```
quantum-canary/
├── src/quantum_canary/      ← The pip package
├── research/                ← Numbered scripts that reproduce the paper
├── results/                 ← Live deployment logs + evaluation results
├── figures/                 ← Final paper figures
└── docs/                    ← Physics + methodology writeups
```

For reproducing the paper end-to-end, see [`research/README.md`](research/README.md).

---

## Citation

If you use Quantum Canary in your research, please cite:

```bibtex
@misc{singh2026quantumcanary,
  author       = {Singh, Kanishka},
  title        = {Quantum Canary: Real-Time Noise Drift Detection for NISQ-Era
                  Quantum Processors},
  year         = {2026},
  howpublished = {\url{https://github.com/kanishkasingh/quantum-canary}},
}
```

---

## License

MIT — see [LICENSE](LICENSE).

---

## Author

**Kanishka Singh** · 9th Grade · Urbana High School
