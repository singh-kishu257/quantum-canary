# Research Pipeline

This folder contains the numbered scripts that reproduce all results from the Quantum Canary paper. The pipeline runs end-to-end from synthetic data generation through live deployment.

---

## Pipeline overview

The scripts execute in numerical order. Each one writes its output to a known location that the next script consumes. Running them in sequence reproduces every result, figure, and JSON output from the paper.

| Script | Purpose | Inputs | Outputs |
|---|---|---|---|
| `1e_pull_data.py` | Generate physics-grounded synthetic data | None | `data/features_data.csv` (15k rows) |
| `2_label_data.py` | Merge synthetic + real IBM anchors, create train/val/test splits | `data/features_data.csv`, IBM calibration data | `data/features_data.csv` (21k rows), `data/split_indices.json` |
| `4_standard_baseline.py` | Per-feature majority-vote threshold baseline | `data/features_data.csv`, `data/split_indices.json` | `results/baseline_standard_results.json` |
| `4c_hotelling_baseline.py` | Hotelling's T² multivariate baseline | same | `models/hotelling_params.json` |
| `5_train_mlp.py` | Train 10-seed MLP ensemble | same | `models/mlp_seed_{0..9}.keras` |
| `6_evaluate.py` | Three-way comparison (threshold, T², MLP) | all of above | `results/evaluation_results.json`, all paper figures |
| `7_realtime_canary.py` | Live deployment on IBM hardware | trained models + IBM credentials | `logs/realtime_log.csv`, live figure |

---

## Key design decisions

### Why a hybrid synthetic + real training set

Real IBM calibration data alone is insufficient because IBM publishes data only at the moment of recalibration — when hardware is at peak health. Training a drift detector exclusively on this data would never expose the model to drifted samples.

The hybrid approach pairs 15,000 physics-grounded Qiskit Aer simulations (parameterised by published Heron r2 fleet statistics and TLS-fluctuation literature) with 6,000 real IBM calibration anchors that ground the simulation in observed hardware behaviour.

### The three-regime synthetic generator

`1e_pull_data.py` produces samples from three distinct physical regimes:

- **Stable** — T1 ≈ 175 µs, gate errors near published Heron r2 medians. Represents fresh post-calibration hardware.
- **Borderline** — T1 ≈ 140 µs (20% drop). Crosses the 15% labelling threshold (so labelled drifted=1) but overlaps the stable distribution. This forces the model to learn a non-trivial decision boundary.
- **Drifted** — T1 ≈ 90 µs (49% drop), gate errors elevated 4-5×. Represents observed TLS-driven degradation per Carroll et al. 2022.

Each batch resamples its noise model, mimicking real qubit-to-qubit and time-to-time variation across the IBM fleet.

### Three independent baselines

The paper compares the MLP against three increasingly sophisticated baselines:

1. **Standard threshold** — per-feature majority vote against training-set means
2. **Hotelling's T²** — multivariate statistical process control (Hotelling 1947)
3. **MLP ensemble** — this work

Both statistical baselines plateau near AUC 0.76, while the MLP achieves 0.92. The plateau is the central finding: linear methods cannot resolve the borderline regime regardless of how rigorously they handle multivariate structure. The MLP wins through learned nonlinearity.

---

## Running the pipeline

Requires Python 3.10+, the dependencies in the root `requirements.txt`, and (for the live monitor) an IBM Quantum account.

```bash
# 1. Set up environment
pip install -r requirements.txt

# 2. Generate synthetic data (~10 minutes on Aer)
python 1e_pull_data.py

# 3. Label and merge with IBM anchors
python 2_label_data.py

# 4. Run baselines
python 4_standard_baseline.py
python 4c_hotelling_baseline.py

# 5. Train MLP ensemble (~2 minutes on CPU)
python 5_train_mlp.py

# 6. Evaluate all three methods
python 6_evaluate.py

# 7. Live deployment (requires IBM credentials)
echo "YOUR_TOKEN" > api_token.txt
echo "YOUR_CRN"   > crn_instance.txt
python 7_realtime_canary.py
```

---

## Reproducibility notes

- All scripts seed their random generators (numpy seed 42 in data generation; per-seed control in MLP training).
- The 21,000-row training CSV is regenerable from `1e_pull_data.py` and `2_label_data.py` and is therefore not committed to the repository — only the scripts that produce it.
- Live deployment results (`results/ibm_kingston_log.csv`) cannot be reproduced exactly because they reflect a specific 24-hour window on IBM hardware. The committed log is the original deployment capture and should be treated as primary data.

---

## Citations to source literature

The physical and statistical foundations referenced by these scripts:

- Carroll, A. et al. (2022). *npj Quantum Information* 8, 132. — TLS-driven T1 fluctuations on IBM hardware.
- Hotelling, H. (1947). *Multivariate Quality Control.* — T² baseline.
- Krantz, P. et al. (2019). *Applied Physics Reviews* 6, 021318. — superconducting qubit noise model.
- Preskill, J. (2018). *Quantum* 2, 79. — NISQ era and the calibration gap.
- Page, E. S. (1954). *Biometrika* 41(1/2), 100-115. — CUSUM (considered, not selected; see paper Discussion).

Full bibliography in the paper's references section.
