# Bundled Model Data

This directory is shipped inside the `quantum-canary` package and contains
the pre-trained MLP ensemble used for live drift inference.

Files expected here for the package to function:

- `mlp_seed_0.keras` through `mlp_seed_9.keras` — 10 MLP models
- `scaler.json` — StandardScaler parameters with keys `mean` and `scale`,
                  each a length-3 list ordered as [F_bell, F_gate, F_coherence]

To populate this directory after running the research pipeline:

```bash
cp models/mlp_seed_*.keras src/quantum_canary/_data/
python -c "
import json, numpy as np
from sklearn.preprocessing import StandardScaler
import pandas as pd, json
df = pd.read_csv('research/data/features_data.csv')
with open('research/data/split_indices.json') as f:
    split = json.load(f)
X = df[['F_bell', 'F_gate', 'F_coherence']].values[split['train']]
s = StandardScaler().fit(X)
with open('src/quantum_canary/_data/scaler.json', 'w') as f:
    json.dump({'mean': s.mean_.tolist(), 'scale': s.scale_.tolist()}, f, indent=2)
"
```

Once these files are in place, `pip install -e .` will produce a working
`quantum-canary` package.
