"""
Command-line interface for Quantum Canary.

Two subcommands:
    check   — run a single drift check on the target backend
    monitor — run continuous monitoring at a fixed interval
"""

from __future__ import annotations
import argparse
import os
import sys
from pathlib import Path


def _read_credential(path_or_value: str | None, env_var: str) -> str:
    """Resolve a credential from the env var, file path, or raw value."""
    if path_or_value is None:
        val = os.environ.get(env_var)
        if val:
            return val.strip()
        raise SystemExit(
            f"No credential provided. Set ${env_var} or pass --token / --instance."
        )
    p = Path(path_or_value)
    if p.is_file():
        return p.read_text(encoding="utf-8").strip()
    return path_or_value.strip()


def cmd_check(args: argparse.Namespace) -> int:
    from quantum_canary import Canary

    token    = _read_credential(args.token,    "IBM_QUANTUM_TOKEN")
    instance = _read_credential(args.instance, "IBM_QUANTUM_CRN")

    canary = Canary(token=token, instance=instance, backend=args.backend)
    result = canary.check()

    print()
    print("Quantum Canary — single check")
    print("─" * 50)
    print(f"  Backend           : {args.backend}")
    print(f"  Timestamp         : {result['timestamp']}")
    print(f"  F_bell            : {result['F_bell']:.4f}")
    print(f"  F_gate            : {result['F_gate']:.4f}")
    print(f"  F_coherence       : {result['F_coherence']:.4f}")
    print(f"  Drift probability : {result['drift_probability']:.4f}")
    print(f"  Uncertainty       : {result['uncertainty']:.4f}")
    print(f"  Verdict           : {result['verdict']}")
    print()
    return 0


def cmd_monitor(args: argparse.Namespace) -> int:
    from quantum_canary import Canary

    token    = _read_credential(args.token,    "IBM_QUANTUM_TOKEN")
    instance = _read_credential(args.instance, "IBM_QUANTUM_CRN")

    canary = Canary(token=token, instance=instance, backend=args.backend)
    canary.monitor(
        interval_minutes = args.interval,
        hours            = args.hours,
        log_path         = args.log,
    )
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="quantum-canary",
        description="Real-time quantum noise drift detection.",
    )
    parser.add_argument(
        "--token", default=None,
        help="IBM Quantum API token, OR a path to a file containing it. "
             "Falls back to the IBM_QUANTUM_TOKEN environment variable.",
    )
    parser.add_argument(
        "--instance", default=None,
        help="IBM Cloud CRN, OR a path to a file. "
             "Falls back to the IBM_QUANTUM_CRN environment variable.",
    )

    sub = parser.add_subparsers(dest="command", required=True)

    p_check = sub.add_parser("check", help="Run a single drift check.")
    p_check.add_argument("--backend", required=True,
                         help="IBM backend name (e.g. ibm_kingston).")
    p_check.set_defaults(func=cmd_check)

    p_mon = sub.add_parser("monitor",
                            help="Run continuous monitoring at fixed intervals.")
    p_mon.add_argument("--backend",  required=True,
                       help="IBM backend name (e.g. ibm_kingston).")
    p_mon.add_argument("--interval", type=int,   default=15,
                       help="Minutes between rounds (default 15).")
    p_mon.add_argument("--hours",    type=float, default=24.0,
                       help="Total monitoring duration in hours (default 24).")
    p_mon.add_argument("--log",      default="logs/realtime_log.csv",
                       help="Output CSV log path.")
    p_mon.set_defaults(func=cmd_monitor)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args   = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
